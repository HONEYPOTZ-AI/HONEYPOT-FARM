import React from 'react';

function App() {
  return <div>Welcome to Honeypot Farm</div>;
}

export default App;
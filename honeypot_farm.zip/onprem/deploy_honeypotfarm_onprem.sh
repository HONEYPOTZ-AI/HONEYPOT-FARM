#!/bin/bash
echo 'Deploying Honeypot Farm on-prem...'